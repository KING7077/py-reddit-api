# CHANGELOG

## February 19, 2022

Minor changes to the description of the project - 1.1.2

## February 19, 2022

Minor changes to the description of the project - 1.1.1

## February 19, 2022

The project actually works now - 1.1.0

## February 18, 2022

Minor changes to make the project more usuable - 1.0.6

## February 18, 2022

Minor changes to make the project more usuable - 1.0.5

## February 18, 2022

Minor changes to make the project more usuable - 1.0.4

## February 18, 2022

Minor changes to make the project more usuable - 1.0.3

## February 18, 2022

Minor changes to the description of the project - 1.0.2

## February 18, 2022

Initial release - 1.0.1
