"""
py-reddit: Reddit and python, made simple.
~~~~~~~~~~~~~~~~~~~
A basic wrapper for managing reddit submissions.
:copyright: (c) 2022-present KING7077
:license: MIT, see LICENSE for more details.
"""


from .reddit import *
